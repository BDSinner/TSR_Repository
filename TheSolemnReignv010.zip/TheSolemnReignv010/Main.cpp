#include <iostream>
#include <SDL.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

//Screen dimension constants
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;

//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The surface contained by the window
SDL_Surface* gScreenSurface = NULL;

//The image we will load and show on the screen
SDL_Surface* gHelloWorld = NULL;


bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		//Create window
		gWindow = SDL_CreateWindow("SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			//Get window surface
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//Loads the Main Menu screen.
	gHelloWorld = SDL_LoadBMP("Main Menu Temp.bmp");
	if (gHelloWorld == NULL)
	{
		printf("Unable to load image %s! SDL Error: %s\n", "Main Menu Temp.bmp", SDL_GetError());
		success = false;
	}

	return success;
}

void close()
{
	//Deallocate surface
	SDL_FreeSurface(gHelloWorld);
	gHelloWorld = NULL;

	//Destroy window
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	//Quit SDL subsystems
	SDL_Quit();
}



int main(int argc, char * argv[])
{

	int mainMenu, newGame, loadGame, inGame, newFile;
	string playerNameSlot1, playerGenderSlot1, playerNameSlot2, playerGenderSlot2, playerNameSlot3, playerGenderSlot3, exitLoadGame, pleaseType1or2, locationCommand, playerLocation;
	
	string keepPlaying = "True";


	/*Start up SDL and create window
	if (!init())
	{
		printf("Failed to initialize!\n");
	}
	else
	{
		//Load media
		if (!loadMedia())
		{
			printf("Failed to load media!\n");
		}
		else
		{
			//Apply the image
			SDL_BlitSurface(gHelloWorld, NULL, gScreenSurface, NULL);

			//Update the surface
			SDL_UpdateWindowSurface(gWindow);

			//Wait a minute
			SDL_Delay(60000);
		}
	}

	//Free resources and close SDL
	close();
	

	system("CLS");
	cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
	//"system ("CLS")" clears the screen once more to completely remove anything on the screen.
	system("CLS");
	*/

	while (keepPlaying == "True") {
		cout << "            The Solemn Reign            " << endl;
		cout << "                v 0.1.0                 " << endl;
		cout << "       Developed by The 1T3S Team       " << endl;
		cout << "----------------------------------------" << endl;
		cout << "               Main Menu                " << endl;
		cout << "                                        " << endl;
		cout << "              New Game (1)              " << endl;
		cout << "             Load Game (2)              " << endl;
		cout << "                  Quit (3)              " << endl;
		cout << "                                        " << endl;
		cin >> mainMenu;


		system("CLS");
		cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
		system("CLS");

		if (mainMenu == 1) {
			cout << "                                        " << endl;
			cout << "              New Game                  " << endl;
			cout << "----------------------------------------" << endl;
			cout << "                                        " << endl;
			cout << "             SLOT 1 (1)                 " << endl;
			cout << "             SLOT 2 (2)                 " << endl;
			cout << "             SLOT 3 (3)                 " << endl;
			cout << "                                        " << endl;

			cin >> newGame;

			if (newGame == 1) {

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "          What is your name?            " << endl;
				cout << "          ";
				cin >> playerNameSlot1;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "What is your gender, "<<playerNameSlot1<<"?" << endl;
				cout << "          ";
				cin >> playerGenderSlot1;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "             Now Saving...              " << endl;
				cout << "                                        " << endl;

				ofstream slot1;
				slot1.open("Slot1.txt");
				slot1 << "Name: " << playerNameSlot1 << endl << "Gender: " << playerGenderSlot1;
				slot1.close();

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");


				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "        Your game is now saved.         " << endl;
				cout << "                                        " << endl;
				cout << "       Press any button to exit.        " << endl;
				cout << "                                        " << endl;
				cin.get();

			}

			else if (newGame == 2) {

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "          What is your name?            " << endl;
				cout << "          ";
				cin >> playerNameSlot2;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "What is your gender, " << playerNameSlot2 << "?" << endl;
				cout << "          ";
				cin >> playerGenderSlot2;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "             Now Saving...              " << endl;
				cout << "                                        " << endl;

				ofstream slot2;
				slot2.open("Slot2.txt");
				slot2 << "Name: " << playerNameSlot2 << endl << "Gender: " << playerGenderSlot2;
				slot2.close();

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");


				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "        Your game is now saved.         " << endl;
				cout << "                                        " << endl;
				cout << "       Press any button to exit.        " << endl;
				cout << "                                        " << endl;
				cin.get();

			}

			else if (newGame == 3) {

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "          What is your name?            " << endl;
				cout << "          ";
				cin >> playerNameSlot3;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "What is your gender, " << playerNameSlot3 << "?" << endl;
				cout << "          ";
				cin >> playerGenderSlot3;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "             Now Saving...              " << endl;
				cout << "                                        " << endl;

				ofstream slot3;
				slot3.open("Slot3.txt");
				slot3 << "Name: " << playerNameSlot3 << endl << "Gender: " << playerGenderSlot3;
				slot3.close();

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");


				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "        Your game is now saved.         " << endl;
				cout << "                                        " << endl;
				cout << "       Press any button to exit.        " << endl;
				cout << "                                        " << endl;
				cin.get();

			}

			newFile = 1;

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									  //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
			keepPlaying = "True";
		}

		else if (mainMenu == 2) {
			cout << "                                        " << endl;
			cout << "             Load Game                  " << endl;
			cout << "----------------------------------------" << endl;
			cout << "                                        " << endl;
			cout << "             SLOT 1 (1)                 " << endl;
			cout << "             SLOT 2 (2)                 " << endl;
			cout << "             SLOT 3 (3)                 " << endl;
			cout << "                                        " << endl;

			cin >> loadGame;

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
										   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
		
			cout << "           The Solemn Reign             " << endl;
			cout << "----------------------------------------" << endl;
			cout << "                                        " << endl;

			if (loadGame == 1) {
				string line;
				ifstream load1;
				load1.open("Slot1.txt");
				
				if (load1.is_open())
				{
					while (getline(load1, line))
					{
						cout << line << '\n';
					}

					cout << "                                        " << endl;
					cout << "      Enter any command to continue.    " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

					
				}

				else {
					cout << "                                        " << endl;
					cout << "       There is no Save Data here.      " << endl;
					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

				}

				load1.close();

			}

			else if (loadGame == 2) {
				string line;
				ifstream load2;
				load2.open("Slot2.txt");

				if (load2.is_open())
				{
					while (getline(load2, line))
					{
						cout << line << '\n';
					}

					cout << "                                        " << endl;
					cout << "      Enter any command to continue.    " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;


				}

				else {
					cout << "                                        " << endl;
					cout << "       There is no Save Data here.      " << endl;
					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

				}

				load2.close();

			}

			else if (loadGame == 3) {
				string line;
				ifstream load3;
				load3.open("Slot3.txt");

				if (load3.is_open())
				{
					while (getline(load3, line))
					{
						cout << line << '\n';
					}

					cout << "                                        " << endl;
					cout << "      Enter any command to continue.    " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;


				}

				else {
					cout << "                                        " << endl;
					cout << "       There is no Save Data here.      " << endl;
					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

				}

				load3.close();

			}

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
										   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
			keepPlaying = "True";
		}

		else if (mainMenu == 3) {

			cout << "            The Solemn Reign            " << endl;
			cout << "                v 0.1.0                 " << endl;
			cout << "       Developed by The 1T3S Team       " << endl;
			cout << "----------------------------------------" << endl;
			cout << "         Thanks for Playing!!!!         " << endl;
			cout << "                                        " << endl;

			return 0;

		}

		else {
			cout << "                                        " << endl;
			cout << "           Please type 1 or 2           " << endl;
			cout << "                                        " << endl;
			cout << "      Enter any command to go back.     " << endl;
			cout << "                                        " << endl;
			cin >> pleaseType1or2;

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									  //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
			keepPlaying = "True";
		}
	
		system("CLS");
		cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
		system("CLS");

		inGame = 1;
		if (newFile = 1){ 
			playerLocation = "A"; 
			locationCommand = "S3cr3tC0d3";
		}

		while(inGame == 1){

	


			if (playerLocation == "A") {
				if (locationCommand == "S3cr3tC0d3"){
				
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------	  		       Library    |     Museum               ------------" << endl;
					cout << "-------------				     (a)              (b)                ------------" << endl;
					cout << "-------------   Ian's House       |  BF's House |          My House ------------" << endl;
					cout << "                    (0)                 (1)                  (2)                " << endl;
					cout << "                                                                                " << endl;
					cout << "           Luke and Cora's House  |Chief's House|        Carl, Becky            " << endl;
					cout << "(c)                                                   and Emma's House       (d)" << endl;
					cout << "                    (3)                 (4)                  (5)                " << endl;
					cout << "                                                                                " << endl;
					cout << "            Max and Fred's House  |Amanda, Dana,|         Joe, Sam              " << endl;
					cout << "                                  Bella and Ryan's       and Nikki's            " << endl;
					cout << "                                       House                House               " << endl;
					cout << "-------------       (6)                 (7)                  (8)    ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "Choose where to go by typing the corresponding number below.                    " << endl;
					playerLocation = "A";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

				if (locationCommand == "A" || locationCommand == "a") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------	  		       Library    |     Museum               ------------" << endl;
					cout << "-------------				     (a)              (b)                ------------" << endl;
					cout << "-------------   Ian's House       |  BF's House |          My House ------------" << endl;
					cout << "                    (0)                 (1)                  (2)                " << endl;
					cout << "                                                                                " << endl;
					cout << "           Luke and Cora's House  |Chief's House|        Carl, Becky            " << endl;
					cout << "(c)                                                   and Emma's House       (d)" << endl;
					cout << "                    (3)                 (4)                  (5)                " << endl;
					cout << "                                                                                " << endl;
					cout << "            Max and Fred's House  |Amanda, Dana,|         Joe, Sam              " << endl;
					cout << "                                  Bella and Ryan's       and Nikki's            " << endl;
					cout << "                                       House                House               " << endl;
					cout << "-------------       (6)                 (7)                  (8)    ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "Sorry, the library is closed right now." << endl;
					playerLocation = "A";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

				if (locationCommand == "B" || locationCommand == "b") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------	  		       Library    |     Museum               ------------" << endl;
					cout << "-------------				     (a)              (b)                ------------" << endl;
					cout << "-------------   Ian's House       |  BF's House |          My House ------------" << endl;
					cout << "                    (0)                 (1)                  (2)                " << endl;
					cout << "                                                                                " << endl;
					cout << "           Luke and Cora's House  |Chief's House|        Carl, Becky            " << endl;
					cout << "(c)                                                   and Emma's House       (d)" << endl;
					cout << "                    (3)                 (4)                  (5)                " << endl;
					cout << "                                                                                " << endl;
					cout << "            Max and Fred's House  |Amanda, Dana,|         Joe, Sam              " << endl;
					cout << "                                  Bella and Ryan's       and Nikki's            " << endl;
					cout << "                                       House                House               " << endl;
					cout << "-------------       (6)                 (7)                  (8)    ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "Sorry, the museum is closed right now." << endl;
					playerLocation = "A";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

				if (locationCommand == "C" || locationCommand == "c") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------        Apothecary's House                                         " << endl;
					cout << "-------------               (a)                                                 " << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------                                                                (c)" << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                  Farmer's House         " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                       (b)               " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                                         " << endl;
					cout << "-------------                                                                   " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "Choose where to go by typing the corresponding number below.                    " << endl;
					playerLocation = "C";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

				if (locationCommand == "D" || locationCommand == "d") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------	  		       Library    |     Museum               ------------" << endl;
					cout << "-------------				     (a)              (b)                ------------" << endl;
					cout << "-------------   Ian's House       |  BF's House |          My House ------------" << endl;
					cout << "                    (0)                 (1)                  (2)                " << endl;
					cout << "                                                                                " << endl;
					cout << "           Luke and Cora's House  |Chief's House|        Carl, Becky            " << endl;
					cout << "(c)                                                   and Emma's House       (d)" << endl;
					cout << "                    (3)                 (4)                  (5)                " << endl;
					cout << "                                                                                " << endl;
					cout << "            Max and Fred's House  |Amanda, Dana,|         Joe, Sam              " << endl;
					cout << "                                  Bella and Ryan's       and Nikki's            " << endl;
					cout << "                                       House                House               " << endl;
					cout << "-------------       (6)                 (7)                  (8)    ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "Sorry, but the east side of the village is blocked off for now.                 " << endl;
					playerLocation = "A";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

			}
	
			if (playerLocation == "C") {

				if (locationCommand == "A" || locationCommand == "a") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------        Apothecary's House                                         " << endl;
					cout << "-------------               (a)                                                 " << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------                                                                (c)" << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                  Farmer's House         " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                       (b)               " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                                         " << endl;
					cout << "-------------                                                                   " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "We shouldn't go into Luna's house when she's not home.                          " << endl;
					playerLocation = "C";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

				if (locationCommand == "B" || locationCommand == "b") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------        Apothecary's House                                         " << endl;
					cout << "-------------               (a)                                                 " << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------                                                                (c)" << endl;
					cout << "-------------                                                                   " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                  Farmer's House         " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                       (b)               " << endl;
					cout << "-------------   xxxxxxxxxx   xxxxxxxxxx                                         " << endl;
					cout << "-------------                                                                   " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "We shouldn't go into Farmer Reigns' house when he's not home.                   " << endl;
					playerLocation = "C";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}

				if (locationCommand == "C" || locationCommand == "c") {
					cout << "                                  The Solemn Reign                              " << endl;
					cout << "                           Current Location: Main Village                       " << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "-------------	  		       Library    |     Museum               ------------" << endl;
					cout << "-------------				     (a)              (b)                ------------" << endl;
					cout << "-------------   Ian's House       |  BF's House |          My House ------------" << endl;
					cout << "                    (0)                 (1)                  (2)                " << endl;
					cout << "                                                                                " << endl;
					cout << "           Luke and Cora's House  |Chief's House|        Carl, Becky            " << endl;
					cout << "(c)                                                   and Emma's House       (d)" << endl;
					cout << "                    (3)                 (4)                  (5)                " << endl;
					cout << "                                                                                " << endl;
					cout << "            Max and Fred's House  |Amanda, Dana,|         Joe, Sam              " << endl;
					cout << "                                  Bella and Ryan's       and Nikki's            " << endl;
					cout << "                                       House                House               " << endl;
					cout << "-------------       (6)                 (7)                  (8)    ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "-------------                                                       ------------" << endl;
					cout << "--------------------------------------------------------------------------------" << endl;
					cout << "                                                                                " << endl;
					cout << "Choose where to go by typing the corresponding number below.                    " << endl;
					playerLocation = "A";
					cin >> locationCommand;

					system("CLS");
					cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
												   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
					system("CLS");

				}


			}

		}

	}

	return 0;
}