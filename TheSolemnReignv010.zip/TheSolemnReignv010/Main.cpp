#include <iostream>
#include <SDL.h>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(int argc, char * argv[])
{

	int mainMenu, newGame, loadGame;
	string playerNameSlot1, playerGenderSlot1, playerNameSlot2, playerGenderSlot2, playerNameSlot3, playerGenderSlot3, exitLoadGame, pleaseType1or2;
	
	string keepPlaying = "True";

	if (SDL_Init(SDL_INIT_EVERYTHING) < 0)
	{
		cout << "SDL initialization failed. SDL Error: " << SDL_GetError();
	}
	else
	{
		cout << "SDL initialization succeeded!" << endl;
		cout << "Press any button to continue." << endl;
	}

	cin.get();

	system("CLS");
	cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
	//"system ("CLS")" clears the screen once more to completely remove anything on the screen.
	system("CLS");

	while (keepPlaying == "True") {
		cout << "            The Solemn Reign            " << endl;
		cout << "                v 0.1.0                 " << endl;
		cout << "       Developed by The 1T3S Team       " << endl;
		cout << "----------------------------------------" << endl;
		cout << "               Main Menu                " << endl;
		cout << "                                        " << endl;
		cout << "              New Game (1)              " << endl;
		cout << "             Load Game (2)              " << endl;
		cout << "                  Quit (3)              " << endl;
		cout << "                                        " << endl;
		cin >> mainMenu;


		system("CLS");
		cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
		system("CLS");

		if (mainMenu == 1) {
			cout << "                                        " << endl;
			cout << "              New Game                  " << endl;
			cout << "----------------------------------------" << endl;
			cout << "                                        " << endl;
			cout << "             SLOT 1 (1)                 " << endl;
			cout << "             SLOT 2 (2)                 " << endl;
			cout << "             SLOT 3 (3)                 " << endl;
			cout << "                                        " << endl;

			cin >> newGame;

			if (newGame == 1) {

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "          What is your name?            " << endl;
				cout << "          ";
				cin >> playerNameSlot1;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "What is your gender, "<<playerNameSlot1<<"?" << endl;
				cout << "          ";
				cin >> playerGenderSlot1;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "             Now Saving...              " << endl;
				cout << "                                        " << endl;

				ofstream slot1;
				slot1.open("Slot1.txt");
				slot1 << "Name: " << playerNameSlot1 << endl << "Gender: " << playerGenderSlot1;
				slot1.close();

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");


				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "        Your game is now saved.         " << endl;
				cout << "                                        " << endl;
				cout << "       Press any button to exit.        " << endl;
				cout << "                                        " << endl;
				cin.get();

			}

			else if (newGame == 2) {

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "          What is your name?            " << endl;
				cout << "          ";
				cin >> playerNameSlot2;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "What is your gender, " << playerNameSlot2 << "?" << endl;
				cout << "          ";
				cin >> playerGenderSlot2;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "             Now Saving...              " << endl;
				cout << "                                        " << endl;

				ofstream slot2;
				slot2.open("Slot2.txt");
				slot2 << "Name: " << playerNameSlot2 << endl << "Gender: " << playerGenderSlot2;
				slot2.close();

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");


				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "        Your game is now saved.         " << endl;
				cout << "                                        " << endl;
				cout << "       Press any button to exit.        " << endl;
				cout << "                                        " << endl;
				cin.get();

			}

			else if (newGame == 3) {

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "          What is your name?            " << endl;
				cout << "          ";
				cin >> playerNameSlot3;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "What is your gender, " << playerNameSlot3 << "?" << endl;
				cout << "          ";
				cin >> playerGenderSlot3;
				cout << "          " << endl;
				cout << "                                        " << endl;

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");

				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "             Now Saving...              " << endl;
				cout << "                                        " << endl;

				ofstream slot3;
				slot3.open("Slot3.txt");
				slot3 << "Name: " << playerNameSlot3 << endl << "Gender: " << playerGenderSlot3;
				slot3.close();

				system("CLS");
				cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
											   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
				system("CLS");


				cout << "           The Solemn Reign             " << endl;
				cout << "----------------------------------------" << endl;
				cout << "                                        " << endl;
				cout << "        Your game is now saved.         " << endl;
				cout << "                                        " << endl;
				cout << "       Press any button to exit.        " << endl;
				cout << "                                        " << endl;
				cin.get();

			}

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									  //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
			keepPlaying = "True";
		}

		else if (mainMenu == 2) {
			cout << "                                        " << endl;
			cout << "             Load Game                  " << endl;
			cout << "----------------------------------------" << endl;
			cout << "                                        " << endl;
			cout << "             SLOT 1 (1)                 " << endl;
			cout << "             SLOT 2 (2)                 " << endl;
			cout << "             SLOT 3 (3)                 " << endl;
			cout << "                                        " << endl;

			cin >> loadGame;

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
										   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
		
			cout << "           The Solemn Reign             " << endl;
			cout << "----------------------------------------" << endl;
			cout << "                                        " << endl;

			if (loadGame == 1) {
				string line;
				ifstream load1;
				load1.open("Slot1.txt");
				
				if (load1.is_open())
				{
					while (getline(load1, line))
					{
						cout << line << '\n';
					}

					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

					
				}

				else {
					cout << "                                        " << endl;
					cout << "       There is no Save Data here.      " << endl;
					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

				}

				load1.close();

			}

			else if (loadGame == 2) {
				string line;
				ifstream load2;
				load2.open("Slot2.txt");

				if (load2.is_open())
				{
					while (getline(load2, line))
					{
						cout << line << '\n';
					}

					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;


				}

				else {
					cout << "                                        " << endl;
					cout << "       There is no Save Data here.      " << endl;
					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

				}

				load2.close();

			}

			else if (loadGame == 3) {
				string line;
				ifstream load3;
				load3.open("Slot3.txt");

				if (load3.is_open())
				{
					while (getline(load3, line))
					{
						cout << line << '\n';
					}

					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;


				}

				else {
					cout << "                                        " << endl;
					cout << "       There is no Save Data here.      " << endl;
					cout << "                                        " << endl;
					cout << "       Enter any command to exit.       " << endl;
					cout << "                                        " << endl;

					cin >> exitLoadGame;

				}

				load3.close();

			}

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
										   //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
			keepPlaying = "True";
		}

		else if (mainMenu == 3) {

			cout << "            The Solemn Reign            " << endl;
			cout << "                v 0.1.0                 " << endl;
			cout << "       Developed by The 1T3S Team       " << endl;
			cout << "----------------------------------------" << endl;
			cout << "         Thanks for Playing!!!!         " << endl;
			cout << "                                        " << endl;

			return 0;

		}

		else {
			cout << "                                        " << endl;
			cout << "           Please type 1 or 2           " << endl;
			cout << "                                        " << endl;
			cout << "      Enter any command to go back.     " << endl;
			cout << "                                        " << endl;
			cin >> pleaseType1or2;

			system("CLS");
			cout << "Loading..." << flush; //"flush" forces this print to the screen in place of what was in the screen.
									  //"system ("CLS")" clears the screen once more to completely remove anything on the screen.
			system("CLS");
			keepPlaying = "True";
		}
	}
	

	return 0;
}